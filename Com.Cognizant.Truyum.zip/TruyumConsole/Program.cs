﻿using Com.Cognizant.Truyum.Dao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TruyumConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("TestGetMenuItemListAdmin");
            MenuItemDaoCollectionTest.TestGetMenuItemListAdmin();
            Console.WriteLine("\n");

            Console.WriteLine("TestModifyMenuItem");
            MenuItemDaoCollectionTest.TestModifyMenuItem();
            Console.WriteLine("\n");

            Console.WriteLine("TestGetMenuItemListCustomer");
            MenuItemDaoCollectionTest.TestGetMenuItemListCustomer();
            Console.WriteLine("\n");

            Console.WriteLine("TestAddCartItem");
            CartDaoCollectionTest.TestAddCartItem();
            Console.WriteLine("\n");

            Console.WriteLine("TestRemoveCartItem");
            CartDaoCollectionTest.TestRemoveCartItem();
            Console.ReadKey();
        }
    }
}
