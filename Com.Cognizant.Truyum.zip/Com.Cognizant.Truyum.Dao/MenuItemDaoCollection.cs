﻿using Com.Cognizant.Truyum.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Cognizant.Truyum.Dao
{
    public class MenuItemDaoCollection: IMenuItemDao
    {
        private static List<MenuItem> menuItemList;

        public MenuItemDaoCollection()
        {
            if(menuItemList == null)
            {
                menuItemList = new List<MenuItem>();
                menuItemList.Add(new MenuItem(1, "Sandwich", 99.0f, true, new DateTime(2017, 03, 15), "Main Course", true));
                menuItemList.Add(new MenuItem(2, "Burger", 129.00f, true, new DateTime(2017, 12, 23), "Main Course", false));
                menuItemList.Add(new MenuItem(3, "Pizza", 149.00f, true, new DateTime(2018, 08, 21), "Main Course", false));
                menuItemList.Add(new MenuItem(4, "French Fries", 57.00f, false, new DateTime(2017, 07, 02), "Starters", true));
                menuItemList.Add(new MenuItem(1, "Chocolate Brownie", 32.00f, true, new DateTime(2022, 11, 02), "Dessert", true));
            }
        }

        public List<MenuItem> GetMenuItemListAdmin()
        {
            return menuItemList;
        }

        public List<MenuItem> GetMenuItemListCustomer()
        {
            List<MenuItem> menuItemsForCustomer = new List<MenuItem>();
            foreach(MenuItem menuItem in menuItemList)
            {
                if(menuItem.DateOfLaunch <= DateTime.Now && menuItem.Active == true)
                {
                    menuItemsForCustomer.Add(menuItem);
                }
            }
            return menuItemsForCustomer;
        }
        public void ModifyMenuItem(MenuItem menuItem)
        {
            foreach(MenuItem menu in menuItemList)
            {
                if(menu.Equals(menuItem))
                {
                    menu.Name = menuItem.Name;
                    menu.Price = menuItem.Price;
                    menu.DateOfLaunch = menuItem.DateOfLaunch;
                    menu.Category = menuItem.Category;
                    menu.Active = menuItem.Active;
                    menu.FreeDelivery = menuItem.FreeDelivery;
                    break;
                }
            }
        }

        // DOUBT
        public MenuItem GetMenuItem(long menuItemId)
        {
            foreach(MenuItem menu in menuItemList)
            {
                if (menu.Id == menuItemId)
                    return menu;
            }
            return null;
        }
    }
}
