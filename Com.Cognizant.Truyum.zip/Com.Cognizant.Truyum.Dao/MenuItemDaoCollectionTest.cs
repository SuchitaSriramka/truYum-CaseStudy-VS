﻿using Com.Cognizant.Truyum.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Cognizant.Truyum.Dao
{
    public class MenuItemDaoCollectionTest
    {
        public static void TestGetMenuItemListAdmin()
        {
            MenuItemDaoCollection menuItemDaoCollection = new MenuItemDaoCollection();
            List<MenuItem> menuItemDao = new List<MenuItem>();
            menuItemDao = menuItemDaoCollection.GetMenuItemListAdmin();
            foreach(MenuItem menuItem in menuItemDao)
            {
                Console.WriteLine(menuItem.ToString());
            }

        }

        public static void TestGetMenuItemListCustomer()
        {
            MenuItemDaoCollection menuItemDaoCollection = new MenuItemDaoCollection();
            List<MenuItem> menuItemDao = new List<MenuItem>();
            menuItemDao = menuItemDaoCollection.GetMenuItemListCustomer();
            foreach (MenuItem menuItem in menuItemDao)
            {
                Console.WriteLine(menuItem.ToString());
            }

        }

        public static void TestModifyMenuItem()
        {
            MenuItem menuItem = new MenuItem(1, "Sandwich", 97.00f, true, new DateTime(2022, 04, 22), "Main Course", true);
            MenuItemDaoCollection menuItemDaoCollection = new MenuItemDaoCollection();
            menuItemDaoCollection.ModifyMenuItem(menuItem);
            MenuItem menuItem1 = menuItemDaoCollection.GetMenuItem(1);
            if (menuItem1!= null)
            {
                Console.WriteLine(menuItem1.ToString()); 
            }
        }
    }
}
