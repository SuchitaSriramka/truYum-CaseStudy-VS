﻿using Com.Cognizant.Truyum.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Cognizant.Truyum.Dao
{
    public class CartDaoCollection : ICartDao
    {
        private static Dictionary<long, Cart> userCarts;

        public static Dictionary<long, Cart> UserCarts { get { return userCarts; } }

        public CartDaoCollection()
        {
            if (userCarts == null)
            {
                userCarts = new Dictionary<long, Cart>();
            }
        }

        public void AddCartItem(long userId, long menuItemId)
        {
            MenuItemDaoCollection menuItemDao = new MenuItemDaoCollection();
            MenuItem mi = menuItemDao.GetMenuItem(menuItemId);
            List<MenuItem> menus;
            if (userCarts.ContainsKey(userId))
            {
                foreach (KeyValuePair<long, Cart> kvp in userCarts)
                {
                    if (kvp.Key.Equals(userId))
                    {
                        menus = kvp.Value.MenuItemList;
                        menus.Add(mi);
                    }
                }
            }
            else
            {
                Cart cart = new Cart(new List<MenuItem>());
                cart.MenuItemList.Add(mi);
                userCarts.Add(userId, cart);
            }

        }

        public Cart GetAllCartItems(long userId)
        {
            List<MenuItem> menuItems = UserCarts[userId].MenuItemList;
            double total = 0.00;
            if (menuItems == null)
            {
                throw new CartEmptyException();
            }
            else
            {
                foreach (MenuItem menuItem in menuItems)
                {
                    total += menuItem.Price;
                }

            }
            UserCarts[userId].Total = total;
            return UserCarts[userId];
        }

        public void RemoveCartItem(long userId, long menuItemId)
        {
            List<MenuItem> menuItems = UserCarts[userId].MenuItemList;
            if(menuItems != null)
            {
                  foreach(MenuItem menuItem in menuItems)
                {
                    if(menuItem.Id == menuItemId)
                    {
                        menuItems.Remove(menuItem);
                        if(menuItems.Count == 0)
                        {
                            UserCarts[userId].MenuItemList = null;
                        }
                        break;
                    }
                }
            }
            else
            {
                throw new CartEmptyException();
            }   
        }
    }
}
