﻿using Com.Cognizant.Truyum.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Cognizant.Truyum.Dao
{
    public class CartDaoCollectionTest
    {
        public static void TestAddCartItem()
        {
            CartDaoCollection cartDao = new CartDaoCollection();
            cartDao.AddCartItem(1, 2);
            Cart cart = cartDao.GetAllCartItems(1);
            foreach(MenuItem menuItem in cart.MenuItemList)
            {
                Console.WriteLine(menuItem.ToString());
            }
        }

        public static void TestRemoveCartItem()
        {
            CartDaoCollection cartDao = new CartDaoCollection();
            try
            {
                cartDao.RemoveCartItem(1, 2);
                cartDao.GetAllCartItems(1);
            }
            catch(CartEmptyException cemp)
            {
                Console.WriteLine(cemp.Message);
            }
        }
    }
}
