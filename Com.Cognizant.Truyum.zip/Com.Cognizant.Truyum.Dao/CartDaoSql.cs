﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using Com.Cognizant.Truyum.Model;
using Com.Cognizant.Truyum.Utility;
using System.Security.Cryptography.X509Certificates;

namespace Com.Cognizant.Truyum.Dao
{
    public class CartDaoSql:ICartDao
    {
        private SqlConnection _sqlConnection;
        private SqlCommand _sqlCommand;
        private SqlDataReader _sqlDataReader;

        public void AddCartItem(long userId, long menuItemId)
        {
            using(_sqlConnection = new SqlConnection(Helper.ConnectionString))
            {
                using(_sqlCommand = new SqlCommand())
                {
                    _sqlCommand.Connection = _sqlConnection;
                    _sqlCommand.CommandText = CommandHelper.AddcartItem;
                    _sqlCommand.Parameters.AddWithValue("@userId", userId);
                    _sqlCommand.Parameters.AddWithValue("@menuItemId", menuItemId);
                    _sqlConnection.Open();
                    _sqlCommand.ExecuteNonQuery();
                    _sqlConnection.Close();
                }
            }
        }

        public Cart GetAllCartItems(long userId)
        {
            List<MenuItem> menuItems = new List<MenuItem>();
            using(_sqlConnection = new SqlConnection(Helper.ConnectionString))
            {
                using(_sqlCommand = new SqlCommand)
                {
                    _sqlCommand.Connection = _sqlConnection;
                    _sqlCommand.CommandText = CommandHelper.GetAllCartItems;
                    _sqlCommand.Parameters.AddWithValue("@userId", userId);
                    while (_sqlDataReader.Read())
                    {
                        menuItems.Add(new MenuItem
                        {
                            Id = long.Parse(_sqlDataReader[0].ToString()),
                            Name = _sqlDataReader[1].ToString(),
                            Price = float.Parse(_sqlDataReader[2].ToString()),
                            Active = bool.Parse(_sqlDataReader[3].ToString()),
                            DateOfLaunch = DateUtility.ConvertToDate(_sqlDataReader[4].ToString()),
                            Category = _sqlDataReader[5].ToString(),
                            FreeDelivery = bool.Parse(_sqlDataReader[6].ToString())
                        });
                    }
                }
            }
            Cart cart = new Cart(menuItems);
            if(cart == null)
            {
                throw new CartEmptyException();
            }
            return cart;
        }

        public void RemoveCartItem(long userId, long menuItemId)
        {
           using(_sqlConnection = new SqlConnection(Helper.ConnectionString))
            {
                using(_sqlCommand = new SqlCommand())
                {
                    _sqlCommand.Connection = _sqlConnection;
                    _sqlCommand.CommandText = CommandHelper.RemoveCartItem;
                    _sqlCommand.Parameters.AddWithValue("@menuId", menuItemId);
                    _sqlCommand.Parameters.AddWithValue("@userId", userId);
                    _sqlConnection.Open();
                    _sqlCommand.ExecuteNonQuery();
                    _sqlConnection.Close();
                }
            }
        }
    }
}
