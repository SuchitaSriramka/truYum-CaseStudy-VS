﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Com.Cognizant.Truyum.Model
{
    public class MenuItem
    {
        private long _id;
        private string _name;
        private float _price;
        private bool _active;
        private DateTime _dateOfLaunch;
        private string _category;
        private bool _freeDelivery;

        public long Id { get { return _id; } set { _id = value; } }
        public string Name { get { return _name; } set { _name = value; } }
        public float Price { get { return _price; } set { _price = value; } }
        public bool Active { get { return _active; } set { _active = value; } }
        public DateTime DateOfLaunch { get { return _dateOfLaunch; } set { _dateOfLaunch = value; } }
        public string Category { get { return _category; } set { _category = value; } }
        public bool FreeDelivery { get { return _freeDelivery; } set { _freeDelivery = value; } }

        public MenuItem()
        {

        }
        public MenuItem(long id, string name, float price, bool active, DateTime dateOfLaunch, string category, bool freeDelivery)
        {
            Id = id;
            Name = name;
            Price = price;
            Active = active;
            DateOfLaunch = dateOfLaunch;
            Category = category;
            FreeDelivery = freeDelivery;
        }

        public override string ToString()
        {
            // TODO
            string str = $"{Name}\t{Price}\t{Active}\t{DateOfLaunch.ToString("d")}\t{Category}\t{FreeDelivery}";
            return str;
        }

        public override bool Equals(object obj)
        {
            if(obj == null)
            {
                return false;
            }
            if(!(obj is MenuItem)){
                return false;
            }
            return this.Id == ((MenuItem)obj).Id;
        }

        public override int GetHashCode()
        {
            // TODO
            return base.GetHashCode();
        }
    }
}
